cd models/deform_conv
python setup.py develop
cd ../..