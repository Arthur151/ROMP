python setup.py develop
